# Analytics Lead — scoring and reporting

Read docs/ANALYTICS_HANDOFF.md and docs/INTEGRATION_CHECKLIST.md.
app/utils.py contains the standalone cosine_similarity helper (standard library
only). This package does not include a GPU model, database or analytics API.

1. Use cosine_similarity on finite, nonzero vectors from the SAME model revision.
2. Agree short-passage splitting/aggregation and vector metadata with Hazma/atrangi.
3. Implement reviewable, job-related matching and explicit qualification filters;
   evaluate labeled multilingual pairs before claiming retrieval quality.
4. Provide score explanations and dashboard contracts to Hazma and Ele.
5. Request the completed model_manifest.json before indexing live vectors.

For full HR, define authorized onboarding/leave/payroll/performance metrics with
the module owners. These dashboards are planned, not implemented in this subset.
Use the Analytics prompts in docs/BOB_MODULE_PROMPTS.md.
