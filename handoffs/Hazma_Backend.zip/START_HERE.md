# Hazma — backend integration

Read docs/INTEGRATION_CHECKLIST.md, then docs/API_CONTRACT.md.
This is an integration subset, not a runnable ML server or completed HR backend.

1. Merge integrations/backend_client.py and shared app schemas/utils into your
   backend's package layout; preserve relative imports when relocating them.
2. Add dependencies from requirements-integration.txt to your existing dependency
   manager. Resolve them with your backend's versions before installing.
3. Create authenticated upload + durable job/status APIs. Workers call MLClient,
   validate returned objects with ResumeSchema/EmbeddingResponse and persist them.
4. Own tenant authorization, DB/pgvector, idempotency, retry limits and audit events.
5. Publish your backend OpenAPI to Ele; agree vector metadata/passage rules with
   Analytics. Request private service URL + model manifest from atrangi when ready.

Use Bob's Hazma prompts in docs/BOB_MODULE_PROMPTS.md. Then build employee records,
onboarding, leave, payroll and performance per the shared blueprint.
