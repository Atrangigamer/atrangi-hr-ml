# Ele — frontend integration

Read docs/FRONTEND_HANDOFF.md and docs/INTEGRATION_CHECKLIST.md.
This is a contracts/design handoff, not a completed frontend application.

1. Get Hazma's authenticated backend OpenAPI and durable job-status contract.
   Included openapi.json describes ML only; never call its routes from the browser.
2. Build upload -> job status -> review/correction -> result screens and ATS views.
3. Map agreed backend states to clear UI labels. Handle scanned/corrupt PDFs,
   temporary failures and unknown facts without presenting them as verified values.
4. Build onboarding, leave, payroll and performance UI against Hazma's APIs using
   the shared blueprint. Mock pending APIs explicitly during development.
5. Run the joint synthetic case after atrangi verifies the real GPU deployment.

Use the Ele/shared prompts in docs/BOB_MODULE_PROMPTS.md in your frontend repo.
